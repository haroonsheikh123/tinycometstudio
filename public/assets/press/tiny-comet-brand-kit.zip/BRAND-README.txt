TINY COMET STUDIO - LOGO KIT

Files
  icon.svg / icon.png             App icon (App Store, Google Play, profile pictures)
  logo-light.svg / .png           Full logo for light backgrounds
  logo-dark.svg / .png            Full logo on navy, for dark backgrounds
  mark.svg / mark.png             Comet symbol only (favicon, watermark, loading screen)
  preview.png                     All versions side by side

Use the SVG files whenever possible - they stay sharp at any size.
PNG files are exported at 2x resolution with transparent backgrounds.

Colors
  Navy     #17183F
  Yellow   #FFE07A
  Orange   #FF9A3C
  Coral    #FF5E6E
  Cream    #FFF8EC

Font
  Fredoka (Bold for "tiny comet", SemiBold for "STUDIO")
  Free for commercial use (SIL Open Font License) - fonts.google.com/specimen/Fredoka
  Text in the SVGs is already converted to shapes, so no font install is needed.
